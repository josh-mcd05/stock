In terms of design, my partner and I extracted the data from the API Alpha Vantage as an array. 
From there, we created multiple classes, representing a stock on certain day, the stock in general, and a portfolio.
This was the model of our program and we wrote the methods for x-day average, x-day crossover, value of portfolio, and difference in stock for a start and end day.
Then, we wrote the controller which was similar to lab 7, where a menu was outputted, and also used the menu idea with multiple different cases and even cases inside of a case.
The controller adjusted the model based on the command.
Finally, the view was initially written to work with the controller and display the text interface a user could interact with.

In this assignment, the view was adjusted to also include a GUI so that it is more user friendly with button processing and designated user input
instead of having them input everything at once. Overall, our design made it simple to add a GUI to our view and have all previous functionality work.
